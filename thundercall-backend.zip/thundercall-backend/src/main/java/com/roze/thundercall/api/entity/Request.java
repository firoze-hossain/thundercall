package com.roze.thundercall.api.entity;

import com.roze.thundercall.api.enums.HttpMethod;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "requests")
@Builder
public class Request {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    private String description;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private HttpMethod method;
    @Column(nullable = false, length = 2000)
    private String url;
    @Column(columnDefinition = "TEXT")
    private String headers;
    @Column(columnDefinition = "TEXT")
    private String body;
    @Column(name = "pre_request_script", columnDefinition = "TEXT")
    private String preRequestScript;
    @Column(name = "tests_script", columnDefinition = "TEXT")
    private String testsScript;

    // Authorization tab (Bearer/Basic), saved WITH the request like scripts
    @Column(name = "auth_type")
    private String authType;
    @Column(name = "auth_token", columnDefinition = "TEXT")
    private String authToken;
    @Column(name = "auth_username")
    private String authUsername;
    @Column(name = "auth_password")
    private String authPassword;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "collection_id", nullable = false)
    private Collection collection;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "folder_id")
    private Folder folder;
    @OneToMany(mappedBy = "request", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RequestHistory> history = new ArrayList<>();
    @Column(nullable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;
    @UpdateTimestamp
    private LocalDateTime updatedAt;
}